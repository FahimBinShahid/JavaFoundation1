//Operators in Java
public class IDEbAsic {
    public static void main(String[] args) {

        int Topscore = 80;
        if (Topscore < 100) {
            System.out.println("You got the highest score");
        }
        int SecondScore = 79; //Usage of "&&" Operator....
        if((Topscore > SecondScore) && (Topscore < 100)){
            System.out.println("Greater than SecondScore and less than 100");
        }
        //"||" Operator is showing both conditions are true....
        if((Topscore>90||SecondScore<=90)){
            System.out.println("Either or Both Condition are True");
        }
        //Testing if the values are equal to each other by the "==" operator.
        int newvalue = 50;
        if(newvalue==50){
            System.out.println("It's True");
        }


        boolean isCar = false;
        if(!isCar ){ //Testing if tha opposite value of isCar is true or false ....
            //If it is isCar then it will return False....
            //If it is not isCar it will return True....
            System.out.println("This is not supposed to happen");
        }

        //Ternary Operator
        String makeOfCar = "VolksWagen";
        boolean isDomestic = makeOfCar=="VolksWagen"? false:true;
        if(isDomestic){
            System.out.println("this car is domestic in our country");
        }
        String s = (isDomestic) ? "This car is domestic" : "this car is not domestic";
        System.out.println(s);

// Operator Precedence
        double myFirstValue= 20.00d;
        double mySecondValue = 80.00d;
        double myTotalValue = ((myFirstValue+mySecondValue) * 100.00d);
        System.out.println("MyTotalValue" + myTotalValue);
        double theRemainder = myTotalValue % 40.00d;
        System.out.println("MyTotslRemainder" + theRemainder);
        boolean isNoRemainder = (theRemainder == 0)? true : false;
        System.out.println("isNoReminder = " + isNoRemainder);
        if(!isNoRemainder)
        {
            System.out.println("Got some Reminder");
        }
    }
}