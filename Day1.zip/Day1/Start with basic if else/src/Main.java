public class Main {
    public static void main(String[] args) {

        System.out.println("Hello Newroz");
        boolean isAlien = true;
        if (isAlien == true) {
            System.out.println("It is not an alien");
            System.out.println("And I am scared of alien");

        }
    }
    }
